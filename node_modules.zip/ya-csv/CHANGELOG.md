0.1.3

 - `CsvReader` - BUGFIX: last column was not passed to the `data` listener
 - `CsvWriter` - `null` string written as an empty field rather than throwing an exception
 - executable `reshuffle` script to strip and/or reorder columns of a CSV stream on stdin

0.1.1 - 0.1.2

 - package.json added

0.1.0 

 - minimal implementation
