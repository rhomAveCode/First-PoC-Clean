# ya-csv TODO list

Must have:

 - test coverage
 - get a CSV record as a hash
 - don't quote every field unless explicitly stated

Sometimes later:

 - CSV manipulation utilities
 - distinguish `null` and empty string by quoting
 - support for invalid CSV streams (unescaped quotes within fields etc)
