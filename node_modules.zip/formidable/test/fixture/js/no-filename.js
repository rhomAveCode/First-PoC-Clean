module.exports['generic.http'] = [
  {type: 'file', name: 'upload', filename: '', fixture: 'plain.txt'},
];
